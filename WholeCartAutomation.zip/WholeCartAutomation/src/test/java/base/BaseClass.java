package base;

import java.time.Duration;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public class BaseClass {
    public static WebDriver driver;
    public static WebDriverWait wait;

    // Replace with the actual WholeCart application URL.
    public static final String APP_URL = "http://localhost:3000";

    public static void openBrowser() {
        if (driver == null) {
            driver = new ChromeDriver(); // Selenium Manager resolves driver in supported setups
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(Duration.ZERO);
            wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        }
        driver.get(APP_URL);
    }

    public static void closeBrowser() {
        if (driver != null) {
            driver.quit();
            driver = null;
            wait = null;
        }
    }
}
