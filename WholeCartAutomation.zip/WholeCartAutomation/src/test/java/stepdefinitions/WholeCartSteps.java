package stepdefinitions;

import base.BaseClass;
import pages.*;
import io.cucumber.java.en.*;
import org.junit.Assert;

public class WholeCartSteps {
    private final LoginPage loginPage = new LoginPage();
    private final CataloguePage cataloguePage = new CataloguePage();
    private final ProductPage productPage = new ProductPage();
    private final CartPage cartPage = new CartPage();
    private final CheckoutPage checkoutPage = new CheckoutPage();
    private final OrderPage orderPage = new OrderPage();

    private String orderNumber;

    @Given("the user launches the WholeCart application")
    public void launchApplication() {
        BaseClass.openBrowser();
    }

    @Given("the user is on the Login page")
    public void verifyLoginPage() {
        Assert.assertTrue("Login page was not detected", loginPage.isLoginPageDisplayed());
    }

    @When("the user logs in with username {string} and password {string}")
    public void login(String username, String password) {
        loginPage.login(username, password);
    }

    @When("the user dismisses the password change popup")
    public void dismissPopup() {
        loginPage.dismissPasswordPopupIfPresent();
    }

    @Then("the Catalogue page should be fully loaded")
    public void verifyCatalogue() {
        Assert.assertTrue("Catalogue page not loaded", cataloguePage.isLoaded());
    }

    @When("the user navigates to product {string}")
    public void navigateToProduct(String productName) {
        cataloguePage.openProduct(productName);
    }

    @When("the user selects unit {string} and quantity {string}")
    public void selectUnitAndQuantity(String unit, String quantity) {
        productPage.selectUnitAndQuantity(unit, quantity);
    }

    @When("the user adds the product to cart")
    public void addProductToCart() {
        productPage.addToCart();
    }

    @Then("the user should be redirected to the Cart page")
    public void verifyCartPage() {
        Assert.assertTrue("Cart page/product was not detected", cartPage.isCartPage());
    }

    @Then("the Net total (excl. tax) should be {string}")
    public void verifyNetTotal(String total) {
        Assert.assertTrue("Net total not found: " + total, cartPage.hasText(total));
    }

    @When("the user proceeds to checkout")
    public void proceedToCheckout() {
        cartPage.proceedToCheckout();
    }

    @When("the user selects delivery date {string} and slot {string}")
    public void selectDeliveryDateAndSlot(String date, String slot) {
        // Feature date is dd-MM-yyyy; HTML date input expects yyyy-MM-dd.
        String[] parts = date.split("-");
        String htmlDate = parts[2] + "-" + parts[1] + "-" + parts[0];
        checkoutPage.selectDateAndSlot(htmlDate, slot);
    }

    @When("the user places the order")
    public void placeOrder() {
        checkoutPage.placeOrder();
    }

    @Then("the order should be placed successfully with order number starting with {string}")
    public void verifyOrderPlaced(String prefix) {
        Assert.assertTrue("Order confirmation not detected", orderPage.orderConfirmationVisible());
        orderNumber = orderPage.getOrderNumber();
        Assert.assertTrue("Order number did not start with " + prefix + ": " + orderNumber,
            orderNumber.startsWith(prefix));
    }

    @Then("the user should be able to view the order details")
    public void viewOrderDetails() {
        orderPage.openFirstViewButton();
        Assert.assertTrue("Order number missing from details page",
            orderPage.containsOrderNumber(orderNumber));
    }

    @Then("the order status should be {string}")
    public void verifyOrderStatus(String status) {
        Assert.assertTrue("Order status not found: " + status, orderPage.hasStatus(status));
    }
}
