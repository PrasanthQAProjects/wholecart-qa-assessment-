package stepdefinitions;

import base.BaseClass;
import io.cucumber.java.After;

public class Hooks {
    @After
    public void tearDown() {
        BaseClass.closeBrowser();
    }
}
