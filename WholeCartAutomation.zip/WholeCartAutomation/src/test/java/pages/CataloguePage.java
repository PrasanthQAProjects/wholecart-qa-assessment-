package pages;

import base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class CataloguePage extends BaseClass {
    // Adjust locator to match the actual search input.
    private final By searchBox = By.xpath(
        "//input[@type='search' or contains(translate(@placeholder,'SEARCH','search'),'search') or contains(@name,'search')]"
    );

    public boolean isLoaded() {
        return wait.until(d ->
            d.getPageSource().contains("Catalogue")
            || d.getPageSource().contains("559 products")
        );
    }

    public void openProduct(String productName) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(searchBox)).clear();
        driver.findElement(searchBox).sendKeys(productName);

        // This generic locator may need adjustment if the product name appears in multiple places.
        By product = By.xpath(
            "//*[self::a or self::button or self::h2 or self::h3 or self::div or self::span]"
            + "[normalize-space()=\"" + productName + "\"]"
        );
        wait.until(ExpectedConditions.elementToBeClickable(product)).click();
    }
}
