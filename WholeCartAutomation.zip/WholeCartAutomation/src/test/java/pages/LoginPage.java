package pages;

import base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class LoginPage extends BaseClass {
    // Adjust these locators to match the actual application HTML.
    private final By username = By.name("username");
    private final By password = By.name("password");
    private final By loginButton = By.xpath("//button[normalize-space()='Login']");

    private final By passwordPopupOk = By.xpath(
        "//button[normalize-space()='OK' or normalize-space()='Ok']"
    );

    public boolean isLoginPageDisplayed() {
        return wait.until(d ->
            d.getCurrentUrl().toLowerCase().contains("login")
            || d.getPageSource().contains("Login")
        );
    }

    public void login(String user, String pass) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(username)).clear();
        driver.findElement(username).sendKeys(user);
        driver.findElement(password).clear();
        driver.findElement(password).sendKeys(pass);
        driver.findElement(loginButton).click();
    }

    public void dismissPasswordPopupIfPresent() {
        try {
            wait.until(ExpectedConditions.elementToBeClickable(passwordPopupOk)).click();
        } catch (org.openqa.selenium.TimeoutException ignored) {
            // Popup may not appear on every run.
        }
    }
}
