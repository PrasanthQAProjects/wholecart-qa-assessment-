package pages;

import base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class CartPage extends BaseClass {
    private final By checkoutButton = By.xpath(
        "//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'proceed to checkout')]"
    );

    public boolean isCartPage() {
        return wait.until(d ->
            d.getPageSource().contains("Chef's Namkeen Mix")
            || d.getCurrentUrl().toLowerCase().contains("cart")
        );
    }

    public boolean hasText(String expectedText) {
        return wait.until(d -> d.getPageSource().contains(expectedText));
    }

    public void proceedToCheckout() {
        wait.until(ExpectedConditions.elementToBeClickable(checkoutButton)).click();
    }
}
