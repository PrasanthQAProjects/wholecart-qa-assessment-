package pages;

import base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class CheckoutPage extends BaseClass {
    private final By deliveryDate = By.xpath("//input[@type='date']");
    private final By showSlotsButton = By.xpath(
        "//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'show slots')]"
    );
    private final By placeOrderButton = By.xpath(
        "//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'place order')]"
    );

    public void selectDateAndSlot(String yyyyMmDd, String slot) {
        var date = wait.until(ExpectedConditions.visibilityOfElementLocated(deliveryDate));
        date.clear();
        date.sendKeys(yyyyMmDd);

        wait.until(ExpectedConditions.elementToBeClickable(showSlotsButton)).click();

        By slotOption = By.xpath(
            "//*[self::button or self::label or self::option or self::div or self::span]"
            + "[normalize-space()='" + slot + "']"
        );
        wait.until(ExpectedConditions.elementToBeClickable(slotOption)).click();
    }

    public void placeOrder() {
        wait.until(ExpectedConditions.elementToBeClickable(placeOrderButton)).click();
    }
}
