package pages;

import base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

public class OrderPage extends BaseClass {
    public boolean orderConfirmationVisible() {
        return wait.until(d ->
            d.getPageSource().contains("Order placed!")
            || d.getPageSource().contains("WC-")
        );
    }

    public String getOrderNumber() {
        By orderNumber = By.xpath("//*[contains(normalize-space(.),'WC-')]");
        String text = wait.until(
            ExpectedConditions.visibilityOfElementLocated(orderNumber)
        ).getText();
        // Return the first WC- style token from the displayed text.
        java.util.regex.Matcher matcher =
            java.util.regex.Pattern.compile("WC-[A-Za-z0-9-]+").matcher(text);
        if (matcher.find()) {
            return matcher.group();
        }
        return text.trim();
    }

    public void openFirstViewButton() {
        By viewButton = By.xpath(
            "//button[normalize-space()='View'] | //a[normalize-space()='View']"
        );
        wait.until(ExpectedConditions.elementToBeClickable(viewButton)).click();
    }

    public boolean containsOrderNumber(String orderNumber) {
        return wait.until(d -> d.getPageSource().contains(orderNumber));
    }

    public boolean hasStatus(String status) {
        return wait.until(d -> d.getPageSource().contains(status));
    }
}
