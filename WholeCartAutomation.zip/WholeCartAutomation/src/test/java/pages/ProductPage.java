package pages;

import base.BaseClass;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;

public class ProductPage extends BaseClass {
    // Update these selectors based on the product page DOM.
    private final By unitDropdown = By.xpath(
        "//select[contains(@name,'unit') or contains(@name,'pack') or contains(@id,'unit')]"
    );
    private final By quantityInput = By.xpath("//input[@type='number']");
    private final By addToCartButton = By.xpath(
        "//button[contains(translate(normalize-space(.),'ABCDEFGHIJKLMNOPQRSTUVWXYZ','abcdefghijklmnopqrstuvwxyz'),'add to cart')]"
    );

    public void selectUnitAndQuantity(String unit, String quantity) {
        wait.until(ExpectedConditions.visibilityOfElementLocated(unitDropdown));
        new Select(driver.findElement(unitDropdown)).selectByVisibleText(unit);

        driver.findElement(quantityInput).clear();
        driver.findElement(quantityInput).sendKeys(quantity);
    }

    public void addToCart() {
        wait.until(ExpectedConditions.elementToBeClickable(addToCartButton)).click();
    }
}
