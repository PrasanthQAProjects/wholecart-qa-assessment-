@wholecart @e2e
Feature: WholeCart Complete Purchase Flow

  Background:
    Given the user launches the WholeCart application

  @smoke
  Scenario: Complete purchase of Chef's Namkeen Mix

    Given the user is on the Login page
    When the user logs in with username "buyer1" and password "password"
    And the user dismisses the password change popup
    Then the Catalogue page should be fully loaded

    When the user navigates to product "Chef's Namkeen Mix"
    And the user selects unit "Case" and quantity "5"
    And the user adds the product to cart
    Then the user should be redirected to the Cart page
    And the Net total (excl. tax) should be "₹5464.80"

    When the user proceeds to checkout
    And the user selects delivery date "14-10-2026" and slot "14:00-17:00"
    And the user places the order

    Then the order should be placed successfully with order number starting with "WC-"
    And the user should be able to view the order details
    And the order status should be "placed"
