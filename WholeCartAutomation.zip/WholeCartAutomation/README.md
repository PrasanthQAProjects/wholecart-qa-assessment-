# WholeCart Selenium + Cucumber + Page Object Model

## Requirements
- Java JDK 17+
- Eclipse IDE with Maven support
- Google Chrome
- Access to the WholeCart application

## Setup
1. Extract this ZIP.
2. Open Eclipse → File → Import → Maven → Existing Maven Projects.
3. Select the extracted `WholeCartAutomation` folder and finish.
4. Open `src/test/java/base/BaseClass.java`.
5. Replace `APP_URL` with your real WholeCart URL.
6. Run `src/test/java/runner/TestRunner.java` as JUnit Test.

## Important
The page locators are starter examples because the actual WholeCart HTML was not supplied. If a locator does not match your website, inspect the element in Chrome DevTools and update the corresponding `pages` class.

The feature uses a delivery date of 14 October 2026. The application must allow that date and the selected slot. Test data/order numbers may differ between runs.
