# WholeCart Refund / Exchange Automation (Selenium + Cucumber + POM)

## Flow automated
1. Buyer login → Catalogue → Orders menu → View Order.
2. Verify order date, status, delivery date and cancel/reorder controls.
3. For a delivered order, select product and enter case/piece quantity.
4. Choose Partial Refund, Full Refund, or Exchange → Send Request → verify confirmation popup.
5. Seller login → Home/Orders → Refund menu.
6. Verify request order type, amount and status → Approve or Reject.
7. Login back as buyer and verify status changed to Approved/Rejected.

## Setup
- Java 17+ and Maven 3.9+ required.
- Open this folder as an existing Maven project in Eclipse/IntelliJ.
- Edit `src/test/resources/config.properties` with the WholeCart URL and buyer/seller credentials.
- Update the selectors in `src/test/java/com/wholecart/pages/` to match the actual app DOM. The provided selectors are common label/text-based examples and may need adjustment.
- Run: `mvn test`
- Browser defaults to Chrome. Set `browser=firefox` if desired.

## Important
The application URL, credentials and exact HTML selectors were not included in the request. This is a complete runnable framework scaffold, but the selectors are intentionally centralized and may need to be mapped to your application's actual page elements. Never commit real passwords to Git.
