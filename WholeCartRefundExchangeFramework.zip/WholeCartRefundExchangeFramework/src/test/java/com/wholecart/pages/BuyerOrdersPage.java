package com.wholecart.pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;

public class BuyerOrdersPage extends BasePage {
    private final By ordersMenu = textButton("Orders");
    private final By viewOrder = textButton("View Order");
    private final By orderDate = By.xpath("//*[contains(translate(.,'ORDER DATE','order date'),'order date')]");
    private final By orderStatus = By.xpath("//*[contains(translate(.,'STATUS','status'),'status')]");
    private final By deliveryDate = By.xpath("//*[contains(translate(.,'DELIVERY DATE','delivery date'),'delivery date')]");
    private final By quantity = By.cssSelector("input[name='quantity'], input[id*='quantity'], input[type='number']");
    private final By unitDropdown = By.xpath("//select[contains(@name,'unit') or contains(@id,'unit')] | //select[contains(@name,'type') or contains(@id,'type')]");
    private final By sendRequest = textButton("Send Request");
    private final By confirmation = By.xpath("//*[contains(translate(.,'REQUEST SENT','request sent'),'request sent') or contains(translate(.,'SUCCESS','success'),'success') or contains(translate(.,'SUBMITTED','submitted'),'submitted')]");
    private final By requestStatus = By.xpath("//*[normalize-space()='Approved' or normalize-space()='Rejected' or normalize-space()='Pending']");

    public void openOrdersAndViewDeliveredOrder() {
        click(ordersMenu);
        click(viewOrder);
        // Selectors may need refinement for the app's order table.
        String status = text(orderStatus).toLowerCase();
        if (!status.contains("delivered")) {
            throw new AssertionError("Selected order is not Delivered. Visible status: " + status);
        }
        if (!displayed(orderDate) || !displayed(deliveryDate))
            throw new AssertionError("Order date or delivery date is not displayed.");
    }
    public void selectProductAndQuantity(String amount, String unit) {
        // Select a product row/checkbox. If the app uses a custom checkbox, update this locator.
        By productCheckbox = By.cssSelector("input[type='checkbox']");
        click(productCheckbox);
        type(quantity, amount);
        if (displayed(unitDropdown)) {
            new Select(visible(unitDropdown)).selectByVisibleText(unit);
        } else {
            click(textButton(unit));
        }
    }
    public void chooseRequestAndSend(String type) {
        click(textButton(type));
        click(sendRequest);
    }
    public boolean confirmationDisplayed() { return displayed(confirmation); }
    public String currentRequestStatus() { return text(requestStatus); }
    public boolean orderDatesDisplayed() {
        return displayed(orderDate) && displayed(orderStatus) && displayed(deliveryDate);
    }
}
