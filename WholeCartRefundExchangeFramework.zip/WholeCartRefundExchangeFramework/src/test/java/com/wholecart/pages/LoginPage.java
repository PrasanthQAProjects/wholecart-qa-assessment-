package com.wholecart.pages;

import org.openqa.selenium.By;
import com.wholecart.driver.DriverFactory;

public class LoginPage extends BasePage {
    // Adjust these locators to match the actual WholeCart HTML attributes.
    private final By username = By.cssSelector("input[name='username'], input[id='username'], input[type='email']");
    private final By password = By.cssSelector("input[name='password'], input[id='password'], input[type='password']");
    private final By loginButton = By.xpath("//button[normalize-space()='Login' or normalize-space()='Log in'] | //input[@type='submit']");

    public void openApplication() {
        String url = DriverFactory.config().getProperty("baseUrl", "");
        if (url.isBlank() || url.contains("REPLACE-WITH")) throw new IllegalStateException("Set baseUrl in src/test/resources/config.properties");
        driver.get(url);
    }
    public void login(String user, String pass) {
        type(username, user);
        type(password, pass);
        click(loginButton);
    }
}
