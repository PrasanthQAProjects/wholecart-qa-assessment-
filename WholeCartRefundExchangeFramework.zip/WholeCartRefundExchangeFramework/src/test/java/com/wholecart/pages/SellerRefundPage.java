package com.wholecart.pages;

import org.openqa.selenium.By;

public class SellerRefundPage extends BasePage {
    private final By home = textButton("Home");
    private final By refundMenu = textButton("Refund");
    private final By orderType = By.xpath("//*[contains(translate(.,'ORDER TYPE','order type'),'order type')]");
    private final By amount = By.xpath("//*[contains(translate(.,'AMOUNT','amount'),'amount')]");
    private final By status = By.xpath("//*[contains(translate(.,'STATUS','status'),'status')]");
    private final By approve = textButton("Approve");
    private final By reject = textButton("Reject");
    private final By confirmationPopup = By.xpath("//*[contains(translate(.,'APPROVED','approved'),'approved') or contains(translate(.,'REJECTED','rejected'),'rejected') or contains(translate(.,'SUCCESS','success'),'success')]");

    public void openRefundMenu() {
        if (displayed(home)) click(home);
        click(refundMenu);
    }
    public void verifyRequestDetails() {
        if (!displayed(orderType)) throw new AssertionError("Order type is not visible in seller refund request.");
        if (!displayed(amount)) throw new AssertionError("Amount is not visible in seller refund request.");
        if (!displayed(status)) throw new AssertionError("Status is not visible in seller refund request.");
    }
    public void approveRequest() { click(approve); handleOptionalConfirm(); }
    public void rejectRequest() { click(reject); handleOptionalConfirm(); }
    private void handleOptionalConfirm() {
        // Some apps show a browser confirm; others show a modal. Accept browser confirm if present.
        try {
            driver.switchTo().alert().accept();
        } catch (org.openqa.selenium.NoAlertPresentException ignored) {
            // In-app toast/modal is asserted by status on the next page.
        }
    }
}
