package com.wholecart.pages;

import java.time.Duration;
import org.openqa.selenium.*;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import com.wholecart.driver.DriverFactory;

public abstract class BasePage {
    protected final WebDriver driver = DriverFactory.getDriver();
    protected final WebDriverWait wait = DriverFactory.waitFor();

    protected WebElement visible(By by) {
        return wait.until(ExpectedConditions.visibilityOfElementLocated(by));
    }
    protected WebElement clickable(By by) {
        return wait.until(ExpectedConditions.elementToBeClickable(by));
    }
    protected void click(By by) { clickable(by).click(); }
    protected void type(By by, String value) {
        WebElement element = visible(by);
        element.clear();
        element.sendKeys(value);
    }
    protected boolean displayed(By by) {
        try { return driver.findElement(by).isDisplayed(); }
        catch (NoSuchElementException e) { return false; }
    }
    protected String text(By by) { return visible(by).getText().trim(); }

    // Centralized fallback for buttons/links whose accessible name matches visible text.
    protected By textButton(String label) {
        String safe = label.replace("'", "\\'");
        return By.xpath("//button[normalize-space()='" + safe + "'] | //a[normalize-space()='" + safe + "'] | //*[@role='button' and normalize-space()='" + safe + "']");
    }
}
