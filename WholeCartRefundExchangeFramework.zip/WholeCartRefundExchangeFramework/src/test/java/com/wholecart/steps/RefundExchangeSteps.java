package com.wholecart.steps;

import com.wholecart.driver.DriverFactory;
import com.wholecart.pages.BuyerOrdersPage;
import com.wholecart.pages.LoginPage;
import com.wholecart.pages.SellerRefundPage;
import io.cucumber.java.After;
import io.cucumber.java.en.*;
import org.junit.Assert;

public class RefundExchangeSteps {
    private final LoginPage loginPage = new LoginPage();
    private final BuyerOrdersPage buyerPage = new BuyerOrdersPage();
    private final SellerRefundPage sellerPage = new SellerRefundPage();

    @Given("the buyer opens the WholeCart application")
    public void buyerOpensApplication() { loginPage.openApplication(); }

    @When("the buyer logs in")
    public void buyerLogsIn() {
        loginPage.login(DriverFactory.config().getProperty("buyer.username"), DriverFactory.config().getProperty("buyer.password"));
    }

    @When("the buyer opens Orders and views a delivered order")
    public void buyerOpensDeliveredOrder() { buyerPage.openOrdersAndViewDeliveredOrder(); }

    @Then("order date status and delivery date should be displayed")
    public void verifyOrderDates() { Assert.assertTrue("Order date/status/delivery date should display", buyerPage.orderDatesDisplayed()); }

    @When("the buyer selects a product and enters quantity {string} as {string}")
    public void buyerSelectsProduct(String amount, String unit) { buyerPage.selectProductAndQuantity(amount, unit); }

    @When("the buyer chooses {string} and sends the request")
    public void buyerChoosesRequest(String type) { buyerPage.chooseRequestAndSend(type); }

    @Then("the refund request confirmation should be displayed")
    public void verifyRequestConfirmation() {
        Assert.assertTrue("Request confirmation popup/toast was not detected", buyerPage.confirmationDisplayed());
    }

    @When("the seller logs in and opens the Refund menu")
    public void sellerLogsInAndOpensRefund() {
        // Reuse the browser but start a clean session to avoid buyer/seller role contamination.
        DriverFactory.getDriver().manage().deleteAllCookies();
        loginPage.openApplication();
        loginPage.login(DriverFactory.config().getProperty("seller.username"), DriverFactory.config().getProperty("seller.password"));
        sellerPage.openRefundMenu();
    }

    @Then("the seller should see the request order type amount and status")
    public void sellerVerifiesRequest() { sellerPage.verifyRequestDetails(); }

    @When("the seller approves the refund request")
    public void sellerApproves() { sellerPage.approveRequest(); }

    @When("the seller rejects the refund request")
    public void sellerRejects() { sellerPage.rejectRequest(); }

    @When("the buyer logs in again and checks the request status")
    public void buyerLogsInAgain() {
        DriverFactory.getDriver().manage().deleteAllCookies();
        loginPage.openApplication();
        loginPage.login(DriverFactory.config().getProperty("buyer.username"), DriverFactory.config().getProperty("buyer.password"));
        buyerPage.openOrdersAndViewDeliveredOrder();
        // If the application has a separate request-history page, add navigation here.
    }

    @Then("the buyer request status should be {string}")
    public void buyerStatusShouldBe(String expected) {
        Assert.assertTrue("Expected status " + expected + " but UI status was " + buyerPage.currentRequestStatus(),
                buyerPage.currentRequestStatus().equalsIgnoreCase(expected));
    }

    @After
    public void tearDown() { DriverFactory.quit(); }
}
