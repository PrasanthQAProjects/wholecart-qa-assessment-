package com.wholecart.driver;

import java.io.InputStream;
import java.time.Duration;
import java.util.Properties;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

public final class DriverFactory {
    private static WebDriver driver;
    private static final Properties config = new Properties();

    static {
        try (InputStream in = DriverFactory.class.getClassLoader().getResourceAsStream("config.properties")) {
            if (in == null) throw new IllegalStateException("config.properties not found");
            config.load(in);
        } catch (Exception e) { throw new RuntimeException("Unable to load config.properties", e); }
    }

    private DriverFactory() {}
    public static Properties config() { return config; }
    public static WebDriver getDriver() {
        if (driver == null) {
            String browser = config.getProperty("browser", "chrome").trim().toLowerCase();
            if (browser.equals("firefox")) driver = new FirefoxDriver();
            else {
                ChromeOptions options = new ChromeOptions();
                options.addArguments("--start-maximized");
                driver = new ChromeDriver(options);
            }
            driver.manage().timeouts().implicitlyWait(Duration.ZERO);
        }
        return driver;
    }
    public static WebDriverWait waitFor() {
        return new WebDriverWait(getDriver(), Duration.ofSeconds(
            Long.parseLong(config.getProperty("timeout.seconds", "15"))));
    }
    public static void quit() { if (driver != null) { driver.quit(); driver = null; } }
}
