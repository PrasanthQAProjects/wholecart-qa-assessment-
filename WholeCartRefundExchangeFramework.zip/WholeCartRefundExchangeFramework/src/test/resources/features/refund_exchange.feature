@wholecart @refund
Feature: Buyer refund/exchange request and seller decision

  Background:
    Given the buyer opens the WholeCart application

  @partial_refund
  Scenario: Buyer requests a partial refund and seller approves it
    When the buyer logs in
    And the buyer opens Orders and views a delivered order
    Then order date status and delivery date should be displayed
    When the buyer selects a product and enters quantity "1" as "Case"
    And the buyer chooses "Partial Refund" and sends the request
    Then the refund request confirmation should be displayed
    When the seller logs in and opens the Refund menu
    Then the seller should see the request order type amount and status
    When the seller approves the refund request
    And the buyer logs in again and checks the request status
    Then the buyer request status should be "Approved"

  @full_refund
  Scenario: Buyer requests a full refund and seller rejects it
    When the buyer logs in
    And the buyer opens Orders and views a delivered order
    When the buyer selects a product and enters quantity "1" as "Piece"
    And the buyer chooses "Full Refund" and sends the request
    Then the refund request confirmation should be displayed
    When the seller logs in and opens the Refund menu
    Then the seller should see the request order type amount and status
    When the seller rejects the refund request
    And the buyer logs in again and checks the request status
    Then the buyer request status should be "Rejected"

  @exchange
  Scenario: Buyer submits an exchange request
    When the buyer logs in
    And the buyer opens Orders and views a delivered order
    When the buyer selects a product and enters quantity "1" as "Case"
    And the buyer chooses "Exchange" and sends the request
    Then the refund request confirmation should be displayed
